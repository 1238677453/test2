
import test

print(test.py_test(100))
print(test.py_str('testДима'))
